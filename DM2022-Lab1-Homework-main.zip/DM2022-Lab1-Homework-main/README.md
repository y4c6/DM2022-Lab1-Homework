# DM2022-Lab1-Homework
Homework 1 for ISA5810 
